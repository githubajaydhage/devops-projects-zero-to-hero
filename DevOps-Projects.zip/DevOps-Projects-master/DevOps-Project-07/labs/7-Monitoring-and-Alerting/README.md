# Monitoring and alerting

The purpose of this lab is to review and setup sample monitoring and alerting. 

In this lab, you will:
- Use and review Application Insights logs and metrics
- Setup an Application Insights Availability test
- Use and review Log Analytics along with container insights
