# Deploy sample Application to Container Registry

The purpose of this lab is to deploy the Application to Container Registry. 

In this lab, you will:
- Deploy application to Azure Container Registry
